import './App.css';
import AxiosFetching from './AxiosFetching';

function App() {
  return (
    <div className="App">
      <AxiosFetching/>
    </div>
  );
}

export default App;
