import './App.css';
import DisplayModes from './DisplayModes';

function App() {
  return (
    <div className="App">
      <DisplayModes/>
    </div>
  );
}

export default App;
