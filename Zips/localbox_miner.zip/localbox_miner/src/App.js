import './App.css';
import MoneyLover from './MoneyLover';

function App() {
  return (
    <div className="App">
      <MoneyLover/>
    </div>
  );
}

export default App;
