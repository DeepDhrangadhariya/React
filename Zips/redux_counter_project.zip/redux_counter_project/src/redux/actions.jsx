export const Increment = 'INCREMENT'
export const Decrement = 'DECREMENT'

export const incFunc = () => ({
    type : Increment
})

export const decFunc = () => ({
    type : Decrement
})