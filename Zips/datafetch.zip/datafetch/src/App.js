import logo from './logo.svg';
import './App.css';
import DataFetch from "./DataFetch";

function App() {
  return (
    <div className="App">
      <DataFetch/>
    </div>
  );
}

export default App;
