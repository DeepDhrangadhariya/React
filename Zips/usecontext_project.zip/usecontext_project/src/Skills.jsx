import React from 'react';

const Skills = () => {
  return (
    <section className="skills">
      <h2>Skills</h2>
      <ul>
        <li>JavaScript</li>
        <li>React</li>
        <li>HTML & CSS</li>
        <li>Node.js</li>
        <li>Python</li>
      </ul>
    </section>
  );
};

export default Skills;
