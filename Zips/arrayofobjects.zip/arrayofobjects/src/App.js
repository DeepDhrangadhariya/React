
import './App.css';
// import Employee from './Employee';
import Login from './Login';

function App() {
  return (
    <div className="App">
      <Login/>
      {/* <Employee/> */}
    </div>
  );
}

export default App;
