import './App.css';
import PostData from './PostData';

function App() {
  return (
    <div className="App">
      <PostData/>
    </div>
  );
}

export default App;
