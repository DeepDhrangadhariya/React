const initialState = {
    prices : [
        {id : 1, img : 'https://m.media-amazon.com/images/I/61bK6PMOC3L._AC_UF1000,1000_QL80_.jpg' ,name : 'Iphone', price : 900, quantity : 1 ,value : 0},
        {id : 2, img : 'https://m.media-amazon.com/images/I/61k05QwLuML._AC_UF894,1000_QL80_.jpg' ,name : 'IPad', price : 700, quantity : 1 ,value : 0},
        {id : 3, img : 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bWFjYm9vayUyMHByb3xlbnwwfHwwfHx8MA%3D%3D' ,name : 'Macbook', price : 1200, quantity : 1 ,value : 0},
        {id : 4, img : 'https://static1.anpoimages.com/wordpress/wp-content/uploads/2022/08/ignacio-r-3yrJSb2fMT0-unsplash.jpg' ,name : 'Airpods', price : 200, quantity : 1 ,value : 0},
    ]
}
export default initialState