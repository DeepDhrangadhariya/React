import './App.css';
import ProductPage from './ProductPage';

function App() {
  return (
    <div className="App">
      <ProductPage/>
    </div>
  );
}

export default App;
