import './App.css';
import Form from './Form';
// import Aform from './Aform'

function App() {
  return (
    <div className="App">
      <Form/>
      {/* <Aform/> */}
    </div>
  );
}

export default App;
