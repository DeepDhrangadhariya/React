import './App.css';
import './Movie.css';
import Movie from './Movie';

function App() {
  return (
    <div className="App">
      <Movie/>
    </div>
  );
}

export default App;
