import logo from './logo.svg';
import './App.css';
import IsLogged from './IsLogged'

function App() {
  return (
    <div className="App">
      <IsLogged/>
    </div>
  );
}

export default App;
