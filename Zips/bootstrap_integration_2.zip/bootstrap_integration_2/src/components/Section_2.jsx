import React from 'react'

export default function Section_2() {
  return (
    <div className="py-5 bg-image-full" style={{backgroundImage: 'url(https://source.unsplash.com/4ulffa6qoKA/1200x800)'}}>
             {/* Put anything you want here! The spacer below with inline CSS is just for demo purposes! */}
            <div style={{height: '20rem'}}></div>
        </div>
  )
}
