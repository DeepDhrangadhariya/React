import React from 'react'

function EditPost() {
  return (
    <div>EditPost</div>
  )
}

export default EditPost