export const increment = 'INCREMENT'
export const decrement = 'DECREMENT'

export const inFunc = ()=>({
    type : increment
})

export const decFunc = ()=>({
    type : decrement
})