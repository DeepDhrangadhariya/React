import logo from './logo.svg';
import './App.css';
import Controlled from './Controlled';
import Uncontrolled from './Uncontrolled';


function App() {
  
  return (
   <>
      <Controlled/><br/><br/>
      <hr/>
      <Uncontrolled/>
   </>
  );
}

export default App;