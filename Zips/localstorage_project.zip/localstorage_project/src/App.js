
import './App.css';
import './Finance.css'
import Finance from './Finance';

function App() {
  return (
    <div className="App">
      <Finance/>
    </div>
  );
}

export default App;
